package utilities;

import java.awt.Color;

import javax.swing.JFrame;
import geneticalgorithm.*;
import data.*;

public class Frame extends JFrame {

	public Frame() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(1000, 1000);

	}

	public void drawWASN(WASN wasn) {
		getContentPane().add(new WASNPanel(wasn));
		setVisible(true);
	}

	public void drawWASN(WASN wasn, Tasks tasks, WASNChromosome chromosome) {
		getContentPane().add(new WASNPanel(wasn, tasks, chromosome));
		setVisible(true);
	}

	public static void main(String[] args) {
		Frame frame = new Frame();
		WASN wasn = RandomGenerator.generateWASN(950, 900, 20, 0.1, 0.1);
		frame.drawWASN(wasn);
	}

}
