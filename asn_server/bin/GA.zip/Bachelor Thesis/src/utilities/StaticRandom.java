package utilities;

import java.util.Random;

public class StaticRandom {

	static Random random;

	public static double nextDouble() {

		if (random == null)
			random = new Random((long) (Math.random() * Long.MAX_VALUE));

		return random.nextDouble();
	}

	public static void setSeed(long seed) {
		random = new Random(seed);
	}

}
