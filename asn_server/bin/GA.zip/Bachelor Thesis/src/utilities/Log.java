package utilities;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JFrame;

public class Log {

	static Thread thread = null;
	static AtomicBoolean stop;
	static LinkedBlockingQueue<String> queue;
	static String string = "";
	private static Log log = null;
	public String address;

	public Log(String address) {
		queue = new LinkedBlockingQueue<String>();
		stop = new AtomicBoolean(false);
		thread = new Thread(new LogThread());
		thread.start();
		log = this;
		this.address = address;
	}

	/**
	 * creates a dummy log
	 */
	private Log() {

	}

	public static Log get() {
		if (log == null)
			log = new Log();
		return log;
	}

	public void newEntry(String id, long seed) {
		if (thread != null)
			queue.add("{id=" + id + ", s=" + seed + ", ");
	}

	public void addFitness(double fitness) {
		if (thread != null)
			queue.add("f=" + fitness + ", ");
	}

	public void possiblePlacement(boolean b) {
		if (thread != null)
			queue.add("b=" + b + ", ");
	}

	public static void setGenerations(int generations) {
		if (thread != null)
			queue.add("g=" + generations + ", ");
	}

	public void endEntry(double runtime) {
		if (thread != null)
			queue.add("r=" + runtime + "s }");
	}

	public void stop() {
		if (thread != null)
			stop.set(true);
	}

	public static LinkedBlockingQueue<String> getLog() {
		if (thread != null)
			return queue;
		else
			return null;
	}

	public class LogThread implements Runnable {

		public void run() {

			FileWriter fw = null;
			try {
				fw = new FileWriter(address);

				while (!stop.get() || !queue.isEmpty()) {
					String s = queue.take();
					fw.write(s);
					if (s.contains("ms }"))
						fw.write("\n");

				}
				fw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		ArrayList<Entry> list = new ArrayList<Entry>();// readFromFile("output/Logfiles/evaluation
														// files/nodevariation.txt");
		// list.addAll(readFromFile("output/constants.txt"));
		for (int i = 1; i <= 15; i++)
			list.addAll(readFromFile("output/blocks" + i + ".txt"));

		System.out.println("Read from file complete " + list.size());

		HashMap<String, ArrayList<Entry>> mapById = new HashMap<String, ArrayList<Entry>>();

		for (Entry e : list) {
			if (mapById.get(e.id) == null)
				mapById.put(e.id, new ArrayList<Entry>());

			mapById.get(e.id).add(e);
		}

		System.out.println("MapById complete " + mapById.size());

		HashMap<String, Entry> averageById = new HashMap<String, Entry>();

		// average Fitness
		for (String id : mapById.keySet()) {
			Entry average = new Entry();
			average.fitness = new ArrayList<Double>();

			for (int i = 0; i < 2000; i++) {
				double f = 0.0;
				double t = 0.0;
				double best1 = -1, best2 = -1;
				double worst1 = 1000, worst2 = 1000;
				int count = 0;

				for (Entry e : mapById.get(id))
					if (e.fitness.size() > i) {
						count++;
						f += e.fitness.get(i);
						t += e.runtime;
						if (id.equals("7"))
							System.out.println(e.runtime);
						if (e.runtime > best1) {
							best2 = best1;
							best1 = e.runtime;
						}
						if (e.runtime < worst1) {
							worst2 = worst1;
							worst1 = e.runtime;
						}
					}

				f = f / (double) count;
				t = t / (double) count;
				average.fitness.add(f);
				average.runtime = t;
				average.upper95 = best1;
				average.under95 = worst1;

			}
			System.out.println(id + " " + average.under95 + " " + average.runtime + " " + average.upper95);
			averageById.put(id, average);
		}

		JFrame frame = new JFrame("lolll");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1980, 900);
		frame.setContentPane(new MyPanel(averageById));
		frame.setVisible(true);

		FileWriter fw = null;
		try {
			fw = new FileWriter("output/blockgraph.txt");

			fw.write("a b c d\n");
			for (String s : averageById.keySet()) {
				int id = Integer.parseInt(s);
				double runtime = averageById.get(s).runtime;
				double  under95 = runtime - averageById.get(s).under95;
				double  upper95 = averageById.get(s).upper95 - runtime;
				
				fw.write(id + " " + runtime +" "+under95+" "+upper95+"\n");
			}
			fw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	public static void drawFitnessGraph(HashMap<String, Entry> input) {

		for (String id : input.keySet()) {
			Entry e = input.get(id);

		}

	}

	/**
	 * reads from a log file and returns it as an list of entries
	 * 
	 * @param filename
	 *            filename of the file that is read
	 * @return ArrayList of entries of the file
	 */
	public static ArrayList<Entry> readFromFile(String filename) {
		ArrayList<Entry> entrylist = new ArrayList<Entry>();

		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		try {
			int illll = 0;
			String string = reader.readLine();
			System.out.println(illll++);

			String[] outerarr = string.split("}");
			for (int j = 0; j < outerarr.length; j++) {
				Entry entry = new Entry();

				String[] arr = outerarr[j].substring(1, outerarr[j].length() - 1).trim().split(",");
				entry.fitness = new ArrayList<Double>();

				for (int i = 0; i < arr.length; i++) {
					// System.out.println(arr[i]);
					try {
						if (arr[i].contains("s="))
							entry.seed = Long.parseLong(arr[i].trim().substring(2, arr[i].length() - 1));
						else if (arr[i].contains("id="))
							entry.id = arr[i].trim().substring(3, arr[i].length());
						else if (arr[i].contains("f="))
							entry.fitness.add(new Double(arr[i].trim().substring(2, arr[i].length() - 1)));
						else if (arr[i].contains("b="))
							entry.possibleplacement = Boolean
									.parseBoolean(arr[i].trim().substring(2, arr[i].length() - 1));
						else if (arr[i].contains("g="))
							entry.generations = Integer.parseInt(arr[i].trim().substring(2, arr[i].length() - 1));
						else if (arr[i].contains("r="))
							entry.runtime = Double.parseDouble(arr[i].trim().substring(2, arr[i].length() - 2));
					} catch (Exception e) {
					}
				}
				entrylist.add(entry);
				string = reader.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return entrylist;
	}

	static class Entry {
		String id;
		long seed;
		double runtime;
		int generations;
		boolean possibleplacement;
		double under95, upper95;

		ArrayList<Double> fitness;

		public String toString() {
			String s = "{id=" + id + ", s=" + seed + ", ";

			for (double d : fitness)
				s = s + "f=" + d + ", ";

			s = s + "g=" + generations + ", ";
			s = s + "b=" + possibleplacement + ", ";
			s = s + "r=" + runtime + "ms }";

			return s;
		}
	}
}
