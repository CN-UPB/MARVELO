package utilities;

import java.awt.Color;
import java.awt.Graphics;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JPanel;

import utilities.Log.Entry;

public class MyPanel extends JPanel {

	HashMap<String, Entry> averageById;

	MyPanel(HashMap<String, Entry> averageById) {
		this.averageById = averageById;
		this.setSize(1920, 980);
	}

//	public void paintComponent(Graphics g) {
//		int c = 0x000000;
//		for (String s : averageById.keySet()) {
//			Entry e = averageById.get(s);
//			g.setColor(Color.GREEN);
//			int x = 1;
//			for (double f : e.fitness)
//				g.drawLine(x, (int) (1000 - 745 * f), x++, (int) (1000 - 745 * f));
//
//		}
//
//		for (String s : averageById.keySet()) {
//			Entry e = averageById.get(s);
//			if (s.trim().contains("100|1.0|0.25")) {
//				g.setColor(Color.RED);
//				int x = 1;
//				for (double f : e.fitness)
//					g.drawLine(x, (int) (1000 - 745 * f), x++, (int) (1000 - 745 * f));
//			}
//
//		}
//		for (String s : averageById.keySet()) {
//			Entry e = averageById.get(s);
//			if (s.trim().contains("200|1.0|0.25")) {
//				g.setColor(Color.BLUE);
//				int x = 1;
//				for (double f : e.fitness)
//					g.drawLine(x, (int) (1000 - 745 * f), x++, (int) (1000 - 745 * f));
//			}
//
//		}
//	}
	
	public void paintComponent(Graphics g){
		
		for (String s : averageById.keySet()) {
			int id = Integer.parseInt(s);
			double runtime = averageById.get(s).runtime;
			double  under95 = averageById.get(s).under95;
			double  upper95 = averageById.get(s).upper95;
			g.setColor(Color.RED);
			g.fillRect(id*50, 1, 40, (int)(runtime*10));
			g.setColor(Color.BLUE);
			g.drawRect(id*50, 1, 40, (int)(upper95*10));
			g.drawRect(id*50, 1, 40, (int)(under95*10));
			
		}
	}

	class IdFrame extends JFrame {

		IdFrame() {

		}

	}

}
