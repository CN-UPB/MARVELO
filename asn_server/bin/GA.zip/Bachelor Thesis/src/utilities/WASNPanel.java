package utilities;

import geneticalgorithm.*;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import data.*;

public class WASNPanel extends JPanel {

	WASN wasn;
	Tasks tasks;
	WASNChromosome chromosome;
	int offset = 40, width = 40;
	double scale;

	WASNPanel(WASN wasn, Tasks tasks, WASNChromosome chromosome) {
		this.wasn = wasn;
		this.tasks = tasks;
		this.chromosome = chromosome;
		scale = 85;

		repaint();
	}

	WASNPanel(WASN wasn) {
		this.wasn = wasn;
		this.tasks = null;
		this.chromosome = null;
		scale = 95;

		repaint();
	}

	public void paint(Graphics g) {
		super.paint(g);
		double[][] edges = eliminateEdges(wasn);
		setBackground(Color.WHITE);
		g.setColor(Color.LIGHT_GRAY);
		for (int i = 0; i < wasn.getCoords().length; i++)
			for (int j = 0; j < wasn.getCoords().length; j++)
				if (edges[i][j] != 0)
					g.drawLine((int) (scale * wasn.getCoords()[i].X + offset + width / 2),
							(int) (scale * wasn.getCoords()[i].Y + offset + width / 2),
							(int) (scale * wasn.getCoords()[j].X + offset + width / 2),
							(int) (scale * wasn.getCoords()[j].Y + offset + width / 2));

		g.setColor(Color.BLACK);
		for (int i = 0; i < wasn.getCoords().length; i++) {
			Coords c = wasn.getCoords()[i];
			g.drawString(i + " " + wasn.getNodetype()[i], (int) (scale * c.X + offset), (int) (scale * c.Y + offset));
			g.drawOval((int) (scale * c.X + offset), (int) (scale * c.Y + offset), width, width);
		}

		if (tasks != null) {
			g.setColor(Color.BLUE);
			for (int i = 0; i < tasks.getBlockcount(); i++) {
				Coords c = wasn.getCoords()[chromosome.getPlacement()[i]];
				g.drawString(i + " " + tasks.getBlocktype()[i], (int) (scale * c.X + offset + width),
						(int) (scale * c.Y + offset + width));
				g.fillOval((int) (scale * c.X + offset), (int) (scale * c.Y + offset), width, width);
			}

			g.setColor(Color.RED);
			for (int i = 0; i < tasks.getBlockcount(); i++) {
				for (int j = 0; j < tasks.getBlockcount(); j++) {
					if (tasks.getEdges()[i][j]) {
						Coords c1 = wasn.getCoords()[chromosome.getPlacement()[i]];
						Coords c2 = wasn.getCoords()[chromosome.getPlacement()[j]];
						int x1 = (int) ((scale * c1.X + offset + width / 2) + (c1.X < c2.X
								? 0.05 * scale * Math.abs(c1.X - c2.X) : -0.05 * scale * Math.abs(c1.X - c2.X)));
						int y1 = (int) ((scale * c1.Y + offset + width / 2) + (c1.Y < c2.Y
								? 0.05 * scale * Math.abs(c1.Y - c2.Y) : -0.05 * scale * Math.abs(c1.Y - c2.Y)));
						int x2 = (int) ((scale * c2.X + offset + width / 2) + (c1.X < c2.X
								? -0.05 * scale * Math.abs(c1.X - c2.X) : 0.05 * scale * Math.abs(c1.X - c2.X)));
						int y2 = (int) ((scale * c2.Y + offset + width / 2) + (c1.Y < c2.Y
								? -0.05 * scale * Math.abs(c1.Y - c2.Y) : 0.05 * scale * Math.abs(c1.Y - c2.Y)));
						g.drawLine(x1, y1, x2, y2);
						g.fillOval(x2 - width / 8, y2 - width / 8, width / 4, width / 4);
					}
				}
			}

		}

	}

	public double[][] eliminateEdges(WASN wasn) {
		double[][] oldEdges = wasn.getAttenuation();
		double[][] newEdges = new double[oldEdges.length][oldEdges.length];

		for (int i = 0; i < newEdges.length; i++)
			for (int j = 0; j < newEdges.length; j++)
				if (oldEdges[i][j] >= wasn.getSINRth() * wasn.getNoisefloor() / wasn.getSignalpower())
					newEdges[i][j] = oldEdges[i][j];

		return newEdges;

	}

}
