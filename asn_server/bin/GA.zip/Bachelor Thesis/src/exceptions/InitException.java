package exceptions;

public class InitException extends Exception {
	String text;
	
	public InitException(String text){
		super(text);
		this.text = text;
	}
	public String toString(){
		return "a initialisation exception occured: " + text;
	}
	public String getText(){
		return text;
	}

}
