package data;

import java.util.ArrayList;
import java.util.List;

public class Tasks {
	
	/**
	 * data structure for the overlay graph
	 * @author Konrad Horbach
	 */

	private int blockcount;
	private Nodetype[] blocktype;
	private int[] resources;
	private boolean[][] edges;

	/**
	 * creates an object of Tasks
	 * @param blockcount number of processing blocks
	 * @param blocktype	array that describes the block type of the blocks
	 * @param resources	an array that describes the needed resources of the processing blocks
	 * @param edges a matrix that represents the directed edges in the graph
	 */
	public Tasks(int blockcount, Nodetype[] blocktype, int[] resources, boolean[][] edges) {
		this.blockcount = blockcount;
		this.blocktype = blocktype;
		this.resources= resources;
		this.edges = edges;
	}
	
	public int getBlockcount(){
		return blockcount;
	}
	
	public Nodetype[] getBlocktype(){
		return blocktype;
	}
	
	public int[] getResources(){
		return resources;
	}
	public boolean[][] getEdges(){
		return edges;
	}
}
