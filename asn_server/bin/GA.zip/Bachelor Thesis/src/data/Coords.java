package data;

/**
 *	stores a  pair of coordinates 
 * @author Konrad Horbach
 *
 */
public class Coords {
	public double X, Y;
	
	public  Coords(double x, double y){
		this.X = x;
		this.Y = y;
	}
}
