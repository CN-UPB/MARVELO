package data;

import java.util.ArrayList;

/**
 * data structure of an schedule
 * 
 * @author Konrad Horbach
 *
 */
public class Schedule {

	public ArrayList<ArrayList<Transmission>> schedule;
	public ArrayList<boolean[]> active;
	public int slotcounter = -1;
	public int nodecount;
	public Transmission tempTransmission;

	/**
	 * creates a Schedule-object
	 * 
	 * @param nodecount
	 *            number of nodes in the infrastructure graph
	 */
	public Schedule(int nodecount) {
		schedule = new ArrayList<ArrayList<Transmission>>();
		active = new ArrayList<boolean[]>();

		this.nodecount = nodecount;
	}

	/**
	 * returns a whole time slot from the schedule
	 * 
	 * @param i
	 *            identifier of the time slot
	 * @return a list of transmissions
	 */
	public ArrayList<Transmission> getTimeslot(int i) {
		if (schedule.size() <= i)
			schedule.add(new ArrayList<Transmission>());
		return schedule.get(i);
	}

	/**
	 * adds a transmission to a distinct time slot
	 * 
	 * @param slot
	 *            the time slot, where the tranmission should be added
	 * @param t
	 *            the transmission, that should be added
	 */
	public void addTransmission(int slot, Transmission t) {
		for (int i = slotcounter; i < slot; i++) {
			schedule.add(new ArrayList<Transmission>());
			active.add(new boolean[nodecount]);
		}
		slotcounter = slot;
		schedule.get(slot).add(t);
		active.get(slot)[t.source] = true;
		active.get(slot)[t.destination] = true;
	}

	/**
	 * returns if a node is sending or receiving in a time slot
	 * 
	 * @param slot
	 *            the time slot, that is considered
	 * @param node
	 *            the node, whose activity is tested
	 * @return a boolean if thenode is active or not
	 */
	public boolean getNodeActivity(int slot, int node) {
		for (int i = slotcounter; i < slot; i++) {
			schedule.add(new ArrayList<Transmission>());
			active.add(new boolean[nodecount]);
		}
		slotcounter = slot;

		return active.get(slot)[node];
	}

	/**
	 * adds a transmission temporarily, so that i can easily be removed again
	 * 
	 * @param slot,
	 *            in which the transmission is added
	 * @param t
	 *            the transmission, that is added
	 */
	public void addTemporary(int slot, Transmission t) {
		tempTransmission = t;

		for (int i = slotcounter; i < slot; i++) {
			schedule.add(new ArrayList<Transmission>());
			active.add(new boolean[nodecount]);
		}

		slotcounter = slot;
		schedule.get(slotcounter).add(t);
	}

	/**
	 * removes the transmission, that was added temporarily before
	 */
	public void removeTemporary() {
		schedule.get(slotcounter).remove(tempTransmission);
		tempTransmission = null;
	}

	/**
	 * tests if a node is sending in a distinct time slot
	 * 
	 * @param slot
	 *            the time slot
	 * @param sendingnode
	 *            the node
	 * @return a boolean
	 */
	public boolean isSending(int slot, int sendingnode) {
		for (Transmission t : schedule.get(slot))
			if (t.source == sendingnode)
				return true;

		return false;
	}

	/**
	 * @return the string representation of an schedule
	 */
	public String toString() {
		String s = "";

		for (int i = 1; i <= schedule.size(); i++) {
			s += "Slot{ " + i;
			for (Transmission t : schedule.get(i - 1))
				s += ", \n {" + t.source + ", " + t.destination + ", " + t.processingblock + ", " + t.SINR + "}";
			s += "}, \n";
		}

		return s;
	}

	public int getSlotCounter() {
		return slotcounter;
	}

}
