package data;

import java.util.ArrayList;

import utilities.*;

/**
 * provides methods that generate infrastructure graphs (WASN) and overlay
 * graphs (Tasks)
 * 
 * @author Konrad Horbach
 *
 */
public class RandomGenerator {
	/**
	 * generates a random infrastructure graph (WASN) with signal power of 1.0,
	 * noisefloor of 1.0, capacity of 1 per node and a SINR threshold of 0.0625
	 * 
	 * @param max_x
	 *            height of the area, where the graph is generated
	 * @param max_y
	 *            width of the area, where the graph is generated
	 * @param nodecount
	 *            number of nodes in the graph
	 * @param sourceprob
	 *            probability that a node is marked as source
	 * @param sinkprob
	 *            probability that a node is marked as sink
	 * @return a WASN
	 */
	public static WASN generateWASN(double max_x, double max_y, int nodecount, double sourceprob, double sinkprob) {

		Coords[] coords = new Coords[nodecount];
		Nodetype[] nodetype = new Nodetype[nodecount];

		for (int i = 0; i < nodecount; i++) {
			coords[i] = new Coords(StaticRandom.nextDouble() * max_x, StaticRandom.nextDouble() * max_y);
			if (StaticRandom.nextDouble() <= sinkprob)
				nodetype[i] = Nodetype.SINK;
			else if (StaticRandom.nextDouble() <= sourceprob)
				nodetype[i] = Nodetype.SOURCE;
			else
				nodetype[i] = Nodetype.NORMAL;

		}

		double[][] attentuation = new double[nodecount][nodecount];
		for (int i = 0; i < nodecount; i++)
			for (int j = 0; j < nodecount; j++) {
				double distance = Math
						.sqrt(Math.pow(coords[i].X - coords[j].X, 2) + Math.pow(coords[i].Y - coords[j].Y, 2));
				attentuation[i][j] = 1.0 / (distance * distance);
				attentuation[j][i] = attentuation[i][j];
			}

		int[] capacities = new int[nodecount];
		for (int i = 0; i < nodecount; i++)
			capacities[i] = 1;

		double signalpower = 1.0;
		double SINRth = 0.00625;
		double noisefloor = 1.0;

		return new WASN(nodecount, coords, nodetype, capacities, signalpower, SINRth, noisefloor, attentuation);
	}

	public static WASN generateWASN(double max_x, double max_y, int nodecount) {

		Coords[] coords = new Coords[nodecount];
		Nodetype[] nodetype = new Nodetype[nodecount];

		for (int i = 0; i < nodecount; i++) {
			coords[i] = new Coords(StaticRandom.nextDouble() * max_x, StaticRandom.nextDouble() * max_y);
			nodetype[i] = Nodetype.NORMAL;
		}
		
		
		int sink = (int)(StaticRandom.nextDouble()*nodecount);
		int source = (int)(StaticRandom.nextDouble()*nodecount);
		while(sink == source ){
			sink = (int)(StaticRandom.nextDouble()*nodecount);
			source = (int)(StaticRandom.nextDouble()*nodecount);
		}
		nodetype[sink] = Nodetype.SINK;
		nodetype[source] = Nodetype.SOURCE;

		double[][] attentuation = new double[nodecount][nodecount];
		for (int i = 0; i < nodecount; i++)
			for (int j = 0; j < nodecount; j++) {
				double distance = Math
						.sqrt(Math.pow(coords[i].X - coords[j].X, 2) + Math.pow(coords[i].Y - coords[j].Y, 2));
				attentuation[i][j] = 1.0 / (distance * distance);
				attentuation[j][i] = attentuation[i][j];
			}

		int[] capacities = new int[nodecount];
		for (int i = 0; i < nodecount; i++)
			capacities[i] = 1;

		double signalpower = 1.0;
		double SINRth = 0.00625;
		double noisefloor = 1.0;

		return new WASN(nodecount, coords, nodetype, capacities, signalpower, SINRth, noisefloor, attentuation);
	}

	/**
	 * generates a mesh network with signal power of 1.0,noisefloor of 1.0
	 * capacity of 1 per node and a SINR threshold of 0.0625
	 * 
	 * @param width
	 *            number of nodes in a line
	 * @param height
	 *            number of nodes in a column
	 * @param sourceprob
	 *            probability that a node is marked as source
	 * @param sinkprob
	 *            probability that a node is marked as sink
	 * @return a WASN
	 */
	public static WASN generateMeshWASN(int width, int height, double sourceprob, double sinkprob) {
		Coords[] coords = new Coords[width * height];
		Nodetype[] nodetype = new Nodetype[width * height];
		double[][] attentuation = new double[width * height][width * height];

		int counter = 0;
		for (int i = 0; i < height; i++)
			for (int j = 0; j < width; j++) {
				if (StaticRandom.nextDouble() <= sinkprob)
					nodetype[counter] = Nodetype.SINK;
				else if (StaticRandom.nextDouble() <= sourceprob)
					nodetype[counter] = Nodetype.SOURCE;
				else
					nodetype[counter] = Nodetype.NORMAL;
				coords[counter++] = new Coords(j, i);
			}

		for (int i = 0; i < width * height; i++)
			for (int j = 0; j < width * height; j++) {
				double distance = Math
						.sqrt(Math.pow(coords[i].X - coords[j].X, 2) + Math.pow(coords[i].Y - coords[j].Y, 2));

				attentuation[i][j] = 1.0 / (distance * distance);
				attentuation[j][i] = attentuation[i][j];
			}

		int[] capacities = new int[width * height];
		for (int i = 0; i < width * height; i++)
			capacities[i] = 1;

		double signalpower = 1.0;
		double SINRth = 0.0625;
		double noisefloor = 1.0;

		return new WASN(width * height, coords, nodetype, capacities, signalpower, SINRth, noisefloor, attentuation);
	}

	public static WASN generateStaticMeshWASN(int width, int height, int sourceNode, int sinkNode) {
		Coords[] coords = new Coords[width * height];
		Nodetype[] nodetype = new Nodetype[width * height];
		double[][] attentuation = new double[width * height][width * height];

		int counter = 0;
		for (int i = 0; i < height; i++)
			for (int j = 0; j < width; j++) {
				if (counter == sinkNode)
					nodetype[counter] = Nodetype.SINK;
				else if (counter == sourceNode)
					nodetype[counter] = Nodetype.SOURCE;
				else
					nodetype[counter] = Nodetype.NORMAL;
				coords[counter++] = new Coords(j, i);
			}

		for (int i = 0; i < width * height; i++)
			for (int j = 0; j < width * height; j++) {
				double distance = Math
						.sqrt(Math.pow(coords[i].X - coords[j].X, 2) + Math.pow(coords[i].Y - coords[j].Y, 2));

				attentuation[i][j] = 1.0 / (distance * distance);
				attentuation[j][i] = attentuation[i][j];
			}

		int[] capacities = new int[width * height];
		for (int i = 0; i < width * height; i++)
			capacities[i] = 1;

		double signalpower = 1.0;
		double SINRth = 0.0625;
		double noisefloor = 1.0;

		return new WASN(width * height, coords, nodetype, capacities, signalpower, SINRth, noisefloor, attentuation);
	}

	/**
	 * generates a random overlay graph (Tasks) with resources of 1.0 per node
	 * 
	 * @param blockamount
	 *            number of processing blocks
	 * @param sourceprob
	 *            probability, that a block is marked as source
	 * @param sinkprob
	 *            probability, that a block is marked as a sink
	 * @param edgeprob
	 *            probability of an edges between two blocks
	 * @return a Tasks-object
	 */
	public static Tasks generateRandomTasks(int blockamount, double sourceprob, double sinkprob, double edgeprob) {
		Nodetype[] blocktype = new Nodetype[blockamount];
		int[] ressources = new int[blockamount];
		boolean[][] edges = new boolean[blockamount][blockamount];

		for (int i = 0; i < blockamount; i++) {
			ressources[i] = 1;
			double random = StaticRandom.nextDouble();
			blocktype[i] = Nodetype.NORMAL;
			if (random < sourceprob + sinkprob)
				blocktype[i] = Nodetype.SOURCE;
			if (random < sinkprob)
				blocktype[i] = Nodetype.SINK;
		}

		for (int i = 0; i < blockamount; i++)
			for (int j = i; j < blockamount; j++)
				if (StaticRandom.nextDouble() < edgeprob)
					edges[i][j] = true;

		return new Tasks(blockamount, blocktype, ressources, edges);
	}
	
	public static Tasks generateRandomTasks(int blockamount, double edgeprob) {
		Nodetype[] blocktype = new Nodetype[blockamount];
		int[] ressources = new int[blockamount];
		boolean[][] edges = new boolean[blockamount][blockamount];

		for (int i = 0; i < blockamount; i++) {
			ressources[i] = 1;
			double random = StaticRandom.nextDouble();
			blocktype[i] = Nodetype.NORMAL;
		}
		
		int sink = (int)(StaticRandom.nextDouble()*blockamount);
		int source = (int)(StaticRandom.nextDouble()*blockamount);
		while(sink == source && blockamount != 1){
			sink = (int)(StaticRandom.nextDouble()*blockamount);
			source = (int)(StaticRandom.nextDouble()*blockamount);
		}
		blocktype[sink] = Nodetype.SINK;
		blocktype[source] = Nodetype.SOURCE;

		for (int i = 0; i < blockamount; i++)
			for (int j = i; j < blockamount; j++)
				if (StaticRandom.nextDouble() < edgeprob)
					edges[i][j] = true;

		return new Tasks(blockamount, blocktype, ressources, edges);
	}

	/**
	 * generates a overlay graph (Tasks) with a many-to-same topology with on
	 * sink
	 * 
	 * @param sourceblockamount
	 *            number of source blocks
	 * @return a Tasks-object
	 */
	public static Tasks generateManyToSame(int sourceblockamount) {
		Nodetype[] nodetype = new Nodetype[sourceblockamount + 1];
		int[] resources = new int[sourceblockamount + 1];
		boolean[][] edges = new boolean[sourceblockamount + 1][sourceblockamount + 1];

		for (int i = 0; i < sourceblockamount; i++) {
			nodetype[i] = Nodetype.SOURCE;
			resources[i] = 1;
			edges[i][sourceblockamount] = true;
		}

		return new Tasks(sourceblockamount + 1, nodetype, resources, edges);
	}

	/**
	 * generates a overlay graph (Tasks) with linear topology, first block is a
	 * source, last block is a sink
	 * 
	 * @param blockamount
	 *            number of processing blocks
	 * @return a Tasks-object
	 */
	public static Tasks generateTaskChain(int blockamount) {
		Nodetype[] nodetype = new Nodetype[blockamount];
		int[] resources = new int[blockamount];
		boolean[][] edges = new boolean[blockamount][blockamount];
		resources[0] = 1;
		for (int i = 1; i < blockamount; i++) {
			resources[i] = 1;
			edges[i - 1][i] = true;
		}
		nodetype[0] = Nodetype.SOURCE;
		nodetype[blockamount - 1] = Nodetype.SINK;

		return new Tasks(blockamount, nodetype, resources, edges);
	}

	/**
	 * generates the overlay graph (Tasks) from acoustic signal processing
	 * 
	 * @return a Tasks-objectF
	 */
	public static Tasks getTestTasks() {
		Nodetype[] nodetype = { Nodetype.SOURCE, Nodetype.NORMAL, Nodetype.NORMAL, Nodetype.NORMAL, Nodetype.NORMAL,
				Nodetype.NORMAL, Nodetype.SINK };
		int[] resources = { 1, 1, 1, 1, 1, 1, 1 };
		boolean[][] edges = new boolean[7][7];
		edges[0][1] = true;
		edges[1][2] = true;
		edges[2][3] = true;
		edges[2][4] = true;
		edges[3][4] = true;
		edges[4][5] = true;
		edges[5][2] = true;
		edges[5][6] = true;

		return new Tasks(7, nodetype, resources, edges);
	}

}
