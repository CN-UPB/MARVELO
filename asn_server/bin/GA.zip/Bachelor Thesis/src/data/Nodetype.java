package data;

/**
 * enum that describes node and block types
 * @author Konrad HorbachF
 *
 */

public enum Nodetype {
	SOURCE, SINK, NORMAL;
}
