package data;

/**
 * the data strucutre that represents a transmission
 * 
 * @author Konrad Horbach
 *
 */
public class Transmission {

	public int source;
	public int processingblock, nextblock = -1;
	public int destination;
	public double SINR;

	/**
	 * compares the transmission to a transmission, if the sending node, the
	 * receiving node and the processing block is equal
	 * 
	 * @param t
	 *            the compared transmission
	 * @return
	 */
	public boolean equals(Transmission t) {
		return processingblock == t.processingblock && source == t.source && destination == t.destination;
	}
}
