package data;

public class WASN {

	/**
	 * data structure for the infrastructure graph
	 * 
	 * @author Konrad Horbach
	 */

	private int nodecount;
	private Coords[] coords;
	private Nodetype[] nodetype;
	private int[] capacities;
	private double signalpower;
	private double SINRth;
	private double noisefloor;
	private double[][] attenuation;

	/**
	 * creates a WASN-object
	 * 
	 * @param nodecount
	 *            the number of nodes in the network
	 * @param coords
	 *            the coordinates of the the nodes
	 * @param nodetype
	 *            an array that describes the type of an node
	 * @param capacities
	 *            an array that describes the capacitiy of an node
	 * @param signalpower
	 *            the signal power
	 * @param SINRth
	 *            the SINR threshold
	 * @param noisefloor
	 *            the noisefloor
	 * @param attenuation
	 *            a matrix that describes the attenuation between nodes
	 */
	public WASN(int nodecount, Coords[] coords, Nodetype[] nodetype, int[] capacities, double signalpower,
			double SINRth, double noisefloor, double[][] attenuation) {
		this.nodecount = nodecount;
		this.coords = coords;
		this.nodetype = nodetype;
		this.capacities = capacities;
		this.signalpower = signalpower;
		this.SINRth = SINRth;
		this.noisefloor = noisefloor;
		this.attenuation = attenuation;
	}

	public int getNodecount() {
		return nodecount;
	}

	public Coords[] getCoords() {
		return coords;
	}

	public Nodetype[] getNodetype() {
		return nodetype;
	}

	public int[] getCapacities() {
		return capacities;
	}

	public double getSignalpower() {
		return signalpower;
	}

	public double getSINRth() {
		return SINRth;
	}

	public double getNoisefloor() {
		return noisefloor;
	}

	public double[][] getAttenuation() {
		return attenuation;
	}

}
