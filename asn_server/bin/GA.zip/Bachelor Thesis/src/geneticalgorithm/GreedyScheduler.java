package geneticalgorithm;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.math3.genetics.Chromosome;

import data.*;

/**
 * A greedy scheduler, that determines a schedule for mapping a overlay graph to
 * an infrastructure graph
 * 
 * @author Konrad Horbach
 *
 */

public class GreedyScheduler {

	WASN wasn;
	Tasks tasks;
	WASNChromosome chromosome;
	Schedule schedule;

	/**
	 * Constructor of an GreedyScheduler-object
	 * 
	 * @param wasn
	 *            the infrastructue Graph
	 * @param tasks
	 *            the overlay graph
	 * @param chromosome
	 *            suitable chromosome, that stores the placement, the priorities
	 *            and the routing table
	 */
	public GreedyScheduler(WASN wasn, Tasks tasks, WASNChromosome chromosome) {
		this.wasn = wasn;
		this.tasks = tasks;
		this.chromosome = chromosome;
	}

	/**
	 * call thus function to start the scheduling
	 * 
	 * @return the calculated schedule or null, if no schedule can be determined
	 */
	public Schedule schedule() {

		schedule = new Schedule(wasn.getNodecount());

		ArrayList<Transmission> allTransmissions = this.getAllTransmissions();
		if (allTransmissions == null) {
			return null;
		}

		PriorityQueue<Transmission> queue1 = new PriorityQueue<Transmission>(
				new EdgesComparator(chromosome.getPriorities()));
		PriorityQueue<Transmission> queue2 = new PriorityQueue<Transmission>(
				new EdgesComparator(chromosome.getPriorities()));

		queue1.addAll(allTransmissions);

		int slotcounter = 0;

		boolean nothingplaced = true;
		while (!queue1.isEmpty()) {
			Transmission t = queue1.poll();
			if (placeable(slotcounter, t)) {
				schedule.addTransmission(slotcounter, t);
				nothingplaced = false;
			} else
				queue2.add(t);

			if (queue1.isEmpty()) {
				if (nothingplaced) {
					System.out.println(" ## No Transmission placeable");
					return null;
				}
				nothingplaced = true;
				slotcounter++;
				queue1 = queue2;
				queue2 = new PriorityQueue<Transmission>(new EdgesComparator(chromosome.getPriorities()));
			}
		}
		return schedule;

	}

	/**
	 * Tests if a Transmission is placeable in a slot cosidering node activity
	 * and exceeding SINRthreshold
	 */
	public boolean placeable(int slot, Transmission t) {
		// test for SINRthreshold
		schedule.addTemporary(slot, t);

		for (Transmission transmission : schedule.getTimeslot(slot)) {
			double interference = interference(transmission.source, transmission.destination, slot);
			double SINR = (wasn.getAttenuation()[transmission.source][transmission.destination] * wasn.getSignalpower())
					/ (interference + wasn.getNoisefloor());
			t.SINR = SINR;
			if (wasn.getSINRth() > SINR) {
				schedule.removeTemporary();
				return false;
			}
		}
		schedule.removeTemporary();

		// test if node is active
		if (schedule.getNodeActivity(slot, t.destination))
			return false;

		// Multicastadvantage
		if (alreadyBlockSendingInSlot(slot, t))
			return true;

		// test if source is active
		if (schedule.getNodeActivity(slot, t.source))
			return false;

		return true;
	}

	/**
	 * Tests if the source of a transmission already sends in the current slot
	 * of the schedule
	 * 
	 * @param slot
	 *            the current time slot
	 * @param new_t
	 *            the transmission, whose source is tested
	 * @return boolean if source is active or not
	 */
	private boolean alreadyBlockSendingInSlot(int slot, Transmission new_t) {
		for (Transmission t : schedule.schedule.get(slot))
			if (t.source == new_t.source && t.processingblock == new_t.processingblock)
				return true;

		return false;
	}

	public double interference(int source, int destination, int slot) {
		double interference = 0;

		for (int sendingnode = 0; sendingnode < wasn.getNodecount(); sendingnode++) {
			if (schedule.isSending(slot, sendingnode) && sendingnode != source && sendingnode != destination)
				interference += wasn.getAttenuation()[sendingnode][destination] * wasn.getSignalpower();
		}

		return interference;
	}

	/**
	 * Determines all transmissions, that have to take place in mapping the
	 * overlay graph to the infrastructure graph
	 * 
	 * @return a list of all transmisssions
	 */
	public ArrayList<Transmission> getAllTransmissions() {
		ArrayList<Transmission> transmissionList = new ArrayList<Transmission>();
		for (int currentBlock = 0; currentBlock < tasks.getBlockcount(); currentBlock++) {
			for (int nextBlock = 0; nextBlock < tasks.getBlockcount(); nextBlock++)
				if (tasks.getEdges()[currentBlock][nextBlock]) {
					Transmission currentTransmission = new Transmission();
					currentTransmission.processingblock = currentBlock;
					currentTransmission.nextblock = nextBlock;
					currentTransmission.source = chromosome.getPlacement()[currentBlock];
					currentTransmission.destination = chromosome
							.getRoutingtable()[currentTransmission.source][chromosome.getPlacement()[nextBlock]];
					transmissionList.add(currentTransmission);
					int temp1 = -2, temp2 = -2;
					
					while (currentTransmission.destination != chromosome.getPlacement()[nextBlock]) {
						//System.out.println("Destintion=" + currentTransmission.destination + " placement(nextBlock)="
						//		+ chromosome.getPlacement()[nextBlock]);
						Transmission prev = currentTransmission;
						currentTransmission = new Transmission();
						currentTransmission.processingblock = currentBlock;
						currentTransmission.source = prev.destination;
						currentTransmission.nextblock = nextBlock;
//						if (currentTransmission.source == -1)
//							return null;
						
						temp1 = temp2;
						temp2 = prev.destination;
						
						currentTransmission.destination = chromosome
								.getRoutingtable()[currentTransmission.source][chromosome.getPlacement()[nextBlock]];
						if (currentTransmission.destination == -1)
							return null;
						if (!transmissionList.contains(currentTransmission))
							transmissionList.add(currentTransmission);
						
						if(temp1 == currentTransmission.destination || temp2 == currentTransmission.destination){
							System.out.println(chromosome);
							System.exit(0);
						}
					}
					//System.out.println("end allTransmissions");
				}
		}

		return transmissionList;
	}

	/**
	 * comparator, that sorts transmissions considering their priorities
	 */
	class EdgesComparator implements Comparator<Transmission> {

		private double[][] priority;

		public EdgesComparator(double[][] priority) {
			this.priority = priority;
		}

		public int compare(Transmission t1, Transmission t2) {
			return priority[t1.processingblock][t1.nextblock] > priority[t2.processingblock][t2.nextblock] ? 1 : -1;
		}

	}
}
