package geneticalgorithm;

import org.apache.commons.math3.genetics.Chromosome;

import data.*;

/**
 * abstraction of a possible solution
 * 
 * @author Konrad Horbach
 *
 */

public class WASNChromosome extends Chromosome {

	WASN wasn;
	Tasks tasks;
	private Schedule schedule;

	private int[] placement;
	private int[][] routingtable = null;
	private double[][] edgecosts;
	private double[][] priorities;

	/**
	 * creates a new chromosome
	 * 
	 * @param wasn
	 *            infrastructure graph
	 * @param tasks
	 *            overlay graph
	 */
	public WASNChromosome(WASN wasn, Tasks tasks) {
		this.wasn = wasn;
		this.tasks = tasks;
		this.placement = new int[tasks.getBlockcount()];
		this.priorities = new double[tasks.getBlockcount()][tasks.getBlockcount()];
		this.edgecosts = new double[wasn.getNodecount()][wasn.getNodecount()];
	}

	/**
	 * creates a new chromosomes by copying the attributes from another
	 * 
	 * @param chromosome
	 *            chromosome, whose attributes should be copied
	 */
	public WASNChromosome(WASNChromosome chromosome) {
		this.wasn = chromosome.wasn;
		this.tasks = chromosome.tasks;

		this.placement = new int[chromosome.placement.length];
		for (int i = 0; i < this.placement.length; i++)
			this.placement[i] = chromosome.placement[i];

		this.routingtable = new int[chromosome.routingtable.length][chromosome.routingtable.length];
		for (int i = 0; i < this.routingtable.length; i++)
			for (int j = 0; j < this.routingtable.length; j++)
				this.routingtable[i][j] = chromosome.routingtable[i][j];

		this.priorities = new double[chromosome.tasks.getBlockcount()][chromosome.tasks.getBlockcount()];
		for (int i = 0; i < this.priorities.length; i++)
			for (int j = 0; j < this.priorities.length; j++)
				this.priorities[i][j] = chromosome.priorities[i][j];

		this.edgecosts = new double[wasn.getNodecount()][wasn.getNodecount()];
		for (int i = 0; i < this.edgecosts.length; i++)
			for (int j = 0; j < this.edgecosts.length; j++)
				this.edgecosts[i][j] = chromosome.edgecosts[i][j];
	}

	public int[] getPlacement() {
		return placement;
	}

	public double[][] getPriorities() {
		return priorities;
	}

	public void setPriorities(double[][] priorities) {
		this.priorities = priorities;
	}

	public double[][] getEdgecosts() {
		return edgecosts;
	}

	public void setEdgecosts(double[][] edgecosts) {
		this.edgecosts = edgecosts;
	}

	public int[][] getRoutingtable() {
		return routingtable;
	}

	public void setRoutingtable(int[][] routingtable) {
		this.routingtable = routingtable;
	}

	/**
	 * computes the fitness of the chromosome
	 */
	public double fitness() {
		this.setRoutingtable(Routing.dijkstraRouting(this.getEdgecosts()));
		GreedyScheduler gs = new GreedyScheduler(wasn, tasks, this);
		this.schedule = gs.schedule();
		double fitness;
		if (schedule == null)
			fitness = 0;
		else
			fitness = !this.hasPossiblePlacement() ? 1.0 / (schedule.getSlotCounter() + 2)
					: 1.0 / (schedule.getSlotCounter() + 2) + 1;
		return fitness;
	}

	/**
	 * determines if constraints 1 and 2 are fulfilled
	 * 
	 * @return
	 */
	public boolean hasPossiblePlacement() {
		int[] occupiedmemory = new int[wasn.getNodecount()];

		for (int block = 0; block < tasks.getBlockcount(); block++) {

			//error in placement
			if (placement[block] == -1) {
				return false;
			}

			// test source on source
			if (tasks.getBlocktype()[block] == Nodetype.SOURCE
					&& wasn.getNodetype()[placement[block]] != Nodetype.SOURCE)
				return false;

			// test sink on sink
			if (tasks.getBlocktype()[block] == Nodetype.SINK && wasn.getNodetype()[placement[block]] != Nodetype.SINK)
				return false;

			// test capacity
			if (occupiedmemory[placement[block]]
					+ tasks.getResources()[block] <= wasn.getCapacities()[placement[block]]) {
				occupiedmemory[placement[block]] += tasks.getResources()[block];
			} else
				return false;

		}
		return true;
	}

	public int getNodecount() {
		return wasn.getNodecount();
	}

	/**
	 * set the placement of a block to a node
	 * 
	 * @param node
	 * @param block
	 */
	public void placeBlock(int node, int block) {
		placement[block] = node;
	}

	/**
	 * String representation of a chromosome
	 */
	public String toString() {
		String s = ""; //= "Chromosome{ Fitness{" + this.getFitness();
		// placement
		s += "},\n Placement{ ";
		for (int i : placement)
			s += i + ", ";
		//s += "}, \n Schedule{ ";
		//s += schedule;
		// routingtable
		s += "}, \n Routingtable{  \n";
		for (int i = 0; i < routingtable.length; i++) {
			s += "{" + routingtable[i][0];
			for (int j = 1; j < routingtable.length; j++) {
				s += ", " + routingtable[i][j];
			}
			s += "}\n";
		}
		s += " }\n}";
		return s;
	}

}
