package geneticalgorithm;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.ListPopulation;
import org.apache.commons.math3.genetics.Population;

/**
 * Population, thats list of chromosomes is public accessible
 * @author Konrad Horbach
 *
 */
public class PublicListPopulation extends ListPopulation {
	
	public PublicListPopulation(int populationLimit) throws NotPositiveException {
		super(populationLimit);
	}

	public List<Chromosome> getChromosomeList() {
		return super.getChromosomeList();
	}

	/**
	 * generates a new generation containing the fittest chromosomes of the current generation
	 */
	public Population nextGeneration() {
		PublicListPopulation population = new PublicListPopulation(this.getPopulationLimit());

		int size = this.getPopulationSize();

		PriorityQueue<Chromosome> queue = new PriorityQueue<Chromosome>(new MyComparator());

		for (Chromosome c : this.getChromosomeList())
			queue.add(c);

		for (int i = 0; i < size *0.1; i++)
			population.addChromosome(new WASNChromosome((WASNChromosome) queue.poll()));

		return population;
	}

	public String toString() {
		String s = "";

		for (Chromosome c : this.getChromosomeList())
			s += c + " ";

		return s;
	}

	class MyComparator implements Comparator<Chromosome> {

		public int compare(Chromosome o1, Chromosome o2) {
			if (o1.getFitness() > o2.getFitness())
				return -1;
			if (o1.getFitness() < o2.getFitness())
				return 1;
			return 0;
		}

	}
}
