package geneticalgorithm;

import org.apache.commons.math3.genetics.Population;
import org.apache.commons.math3.genetics.StoppingCondition;

/**
 * Stopping condition that affects the Genetic ALgorithm to teminate, when there
 * is no noticeable improvement after a certein number of generations
 * 
 * @author Konrad Horbach
 *
 */
public class NoImprovement implements StoppingCondition {

	final int SECONDCHANCE;
	private int counter;
	private double lastFitness;

	public NoImprovement(int secondchance) {
		this.SECONDCHANCE = secondchance;
	}

	public boolean isSatisfied(Population population) {
		if (population.getFittestChromosome().getFitness() > lastFitness) {
			lastFitness = population.getFittestChromosome().getFitness();
			counter = 0;
			return false;
		}
		if (counter++ < SECONDCHANCE)
			return false;
		else
			return true;
	}

}
