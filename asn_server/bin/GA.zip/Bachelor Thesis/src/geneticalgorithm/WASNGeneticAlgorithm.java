package geneticalgorithm;

import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.CrossoverPolicy;
import org.apache.commons.math3.genetics.GeneticAlgorithm;
import org.apache.commons.math3.genetics.ListPopulation;
import org.apache.commons.math3.genetics.MutationPolicy;
import org.apache.commons.math3.genetics.Population;
import org.apache.commons.math3.genetics.SelectionPolicy;
import org.apache.commons.math3.genetics.StoppingCondition;

import data.*;
import exceptions.InitException;
import utilities.*;

/**
 * 
 * @author Konrad Horbach
 *
 */

public class WASNGeneticAlgorithm extends GeneticAlgorithm {
	int generationsEvolved;

	public WASNGeneticAlgorithm(CrossoverPolicy crossoverPolicy, double crossoverRate, MutationPolicy mutationPolicy,
			double mutationRate, SelectionPolicy selectionPolicy) throws OutOfRangeException {
		super(crossoverPolicy, crossoverRate, mutationPolicy, mutationRate, selectionPolicy);
	}

	public Population evolve(final Population initial, final StoppingCondition condition) {
		Population current = initial;
		generationsEvolved = 0;

		while (!condition.isSatisfied(current)) {
			//System.out.println("generation: " + generationsEvolved);
			Log.get().addFitness(current.getFittestChromosome().getFitness());
			current = nextGeneration(current);
			generationsEvolved++;
		}

		//Log.get().setGenerations(generationsEvolved);
		return current;
	}

	/**
	 * initializes a random start population, that may not consider constraints
	 * 1 and 2
	 * 
	 * @param wasn
	 *            the infrastructure graph that is studies
	 * @param tasks
	 *            the overlay graph that is studied
	 * @param size
	 *            the population size
	 * @param geneticRouting
	 *            if genetic routing is used and if edge costs are created
	 * @param geneticScheduling
	 *            if geneti scheduling is used and if priorities are created
	 * @return a PublicLsitPopulation
	 */
	public static Population initializeRandomPopulation(WASN wasn, Tasks tasks, int size, boolean geneticRouting,
			boolean geneticScheduling) {

		SortedPopulation population = new SortedPopulation(size);

		for (int i = 0; i < size; i++) {
			WASNChromosome chromosome = new WASNChromosome(wasn, tasks);

			for (int block = 0; block < tasks.getBlockcount(); block++) {
				int node = (int) (StaticRandom.nextDouble() * wasn.getNodecount());
				chromosome.placeBlock(node, block);
			}

			// initialize Priorities
			for (int j = 0; j < tasks.getBlockcount(); j++)
				for (int k = 0; k < tasks.getBlockcount(); k++)
					if (geneticScheduling)
						chromosome.getPriorities()[j][k] = (int) (StaticRandom.nextDouble() * tasks.getBlockcount()
								* tasks.getBlockcount());
					else
						chromosome.getPriorities()[j][k] = 0;

			// initialize Edgecosts
			if (!geneticRouting) {
				chromosome.setEdgecosts(Routing.getTransmissionNumber(wasn.getAttenuation(),
						wasn.getSINRth() * wasn.getNoisefloor() / wasn.getSignalpower()));

			} else {
				double[][] newEdges = Routing.eliminateEdges(wasn);
				for (int j = 0; j < wasn.getNodecount(); j++)
					for (int k = 0; k < wasn.getNodecount(); k++)
						if (newEdges[j][k] != 0)
							chromosome.getEdgecosts()[j][k] = StaticRandom.nextDouble()+1;
						else
							chromosome.getEdgecosts()[j][k] = Double.POSITIVE_INFINITY;
			}
			int[][] routing = Routing.dijkstraRouting(chromosome.getEdgecosts());
			chromosome.setRoutingtable(routing);
			population.addChromosome(chromosome);
		}

		return population;

	}

	/**
	 * example of the usage of the Genetic Algorithm
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		increasingNodes();
		increasingBlocks();
		
//		StaticRandom.setSeed(123);
//		SelectionPolicy selectionpolicy = new WASNSelectionPolicy();
//		StoppingCondition stoppingcondition = new NoImprovement(5000);
//		MutationPolicy mutationpolicy = new WASNMutationPolicy(false, true, true, 1);
//		CrossoverPolicy crossoverpolicy = new WASNCrossoverPolicy(false, true, true, 1, true);
//
//		double crossoverrate = 1.0;
//		double mutationrate = 0.1;
//
//		WASN wasn = RandomGenerator.generateWASN(10, 10, 10, 0.3, 0.3);
//		Tasks tasks = RandomGenerator.getTestTasks();
//		System.out.println("init population");
//		Population startpopulation = WASNGeneticAlgorithm.initializeRandomPopulation(wasn, tasks, 200, true, true);
//		System.out.println("starting ga");
//		GeneticAlgorithm geneticalgorithm = new WASNGeneticAlgorithm(crossoverpolicy, crossoverrate, mutationpolicy,
//				mutationrate, selectionpolicy);
//		Population lastpopulation = geneticalgorithm.evolve(startpopulation, stoppingcondition);
//
//		System.out.println(lastpopulation.getFittestChromosome());
//
//		Frame frame = new Frame();
//		frame.drawWASN(wasn, tasks, (WASNChromosome) lastpopulation.getFittestChromosome());
	}

	public static void testing() {
		Log log = new Log("constants.txt");
		int nrOfTrials = 50;
		double crossoverrate;
		double mutationrate;
		int[] populations = { 20, 50, 100, 200 };
		for (crossoverrate = 0.2; crossoverrate <= 1; crossoverrate += 0.2)
			for (mutationrate = 0.05; mutationrate <= 0.25; mutationrate += 0.05)
				for (int populationSize : populations)
					// Debug: sequenced seeds for debugging
					
					for (int i = 0; i < nrOfTrials; i++) {
						
						int seed = i+10000;
						
						StaticRandom.setSeed(seed);
						System.out.flush();
						System.out.print("Trial " + seed + ", c=" + crossoverrate +", m=" + mutationrate + ", p=" + populationSize);

						SelectionPolicy selectionpolicy = new WASNSelectionPolicy();
						StoppingCondition stoppingcondition = new FixedIterationNumber(2000);
						MutationPolicy mutationpolicy = new WASNMutationPolicy();
						CrossoverPolicy crossoverpolicy = new WASNCrossoverPolicy();

						WASN wasn = RandomGenerator.generateWASN(10, 10, 12);
						Tasks tasks = RandomGenerator.getTestTasks();

						Log.get().newEntry("" + populationSize +"|"+ crossoverrate + "|" + mutationrate, seed);
						long time = System.nanoTime();
						Population startpopulation = WASNGeneticAlgorithm.initializeRandomPopulation(wasn, tasks,
								populationSize, true, true);

						//System.out.println("starting ga");
						GeneticAlgorithm geneticalgorithm = new WASNGeneticAlgorithm(crossoverpolicy,
								crossoverrate, mutationpolicy, crossoverrate, selectionpolicy);

						Population lastpopulation = geneticalgorithm.evolve(startpopulation, stoppingcondition);
						double elapsedTime = (System.nanoTime() - time) / 1000000000.0;
						Log.get().possiblePlacement(((WASNChromosome)lastpopulation.getFittestChromosome()).hasPossiblePlacement());
						Log.get().addFitness(lastpopulation.getFittestChromosome().getFitness());
						Log.get().setGenerations(2000);
						Log.get().endEntry(elapsedTime);
						System.out.println(", f=" + lastpopulation.getFittestChromosome().getFitness() + ", t=" +elapsedTime);
						
					}
		Log.get().stop();
	}
	
	public static void increasingNodes(){
		
		int nrOfTrials = 50;
		double crossoverrate=1.0;
		double mutationrate=0.25;
		int populationSize=100;
		
		for(int nodecount = 7; nodecount <= 30 ; nodecount++){
			Log log = new Log("nodes"+nodecount+".txt");
			for (int i = 0; i < nrOfTrials; i++) {
				int seed = i + 222222000;
				
				StaticRandom.setSeed(seed);
				System.out.flush();
				System.out.print("Trial " + seed + ", n=" + nodecount);

				SelectionPolicy selectionpolicy = new WASNSelectionPolicy();
				StoppingCondition stoppingcondition = new FixedIterationNumber(2000);
				MutationPolicy mutationpolicy = new WASNMutationPolicy();
				CrossoverPolicy crossoverpolicy = new WASNCrossoverPolicy();

				WASN wasn = RandomGenerator.generateWASN(10, 10, nodecount);
				Tasks tasks = RandomGenerator.getTestTasks();

				Log.get().newEntry("" +nodecount, seed);
				long time = System.nanoTime();
				Population startpopulation = WASNGeneticAlgorithm.initializeRandomPopulation(wasn, tasks,
						populationSize, true, true);

				//System.out.println("starting ga");
				GeneticAlgorithm geneticalgorithm = new WASNGeneticAlgorithm(crossoverpolicy,
						crossoverrate, mutationpolicy, mutationrate, selectionpolicy);

				Population lastpopulation = geneticalgorithm.evolve(startpopulation, stoppingcondition);
				double elapsedTime = (System.nanoTime() - time) / 1000000000.0;
				Log.get().possiblePlacement(((WASNChromosome)lastpopulation.getFittestChromosome()).hasPossiblePlacement());
				Log.get().addFitness(lastpopulation.getFittestChromosome().getFitness());
				Log.get().setGenerations(2000);
				Log.get().endEntry(elapsedTime);
				System.out.println(", f=" + lastpopulation.getFittestChromosome().getFitness() + ", t=" +elapsedTime);
				}
		}
		Log.get().stop();
	}
	
	public static void increasingBlocks(){
		int nrOfTrials = 50;
		double crossoverrate=1.0;
		double mutationrate=0.25;
		int populationSize=100;
		
		for(int blockcount = 1; blockcount <= 15 ; blockcount++){
			Log log = new Log("blocks"+blockcount+".txt");
			for (int i = 0; i < nrOfTrials; i++) {
				
				int seed = i + 9999000;
				
				StaticRandom.setSeed(seed);
				System.out.flush();
				System.out.print("Trial " + seed + ", b=" + blockcount);

				SelectionPolicy selectionpolicy = new WASNSelectionPolicy();
				StoppingCondition stoppingcondition = new FixedIterationNumber(2000);
				MutationPolicy mutationpolicy = new WASNMutationPolicy();
				CrossoverPolicy crossoverpolicy = new WASNCrossoverPolicy();

				WASN wasn = RandomGenerator.generateWASN(5, 5, 15);
				Tasks tasks = RandomGenerator.generateRandomTasks(blockcount, 0.2);

				Log.get().newEntry("" +blockcount, seed);
				long time = System.nanoTime();
				Population startpopulation = WASNGeneticAlgorithm.initializeRandomPopulation(wasn, tasks,
						populationSize, true, true);

				//System.out.println("starting ga");
				GeneticAlgorithm geneticalgorithm = new WASNGeneticAlgorithm(crossoverpolicy,
						crossoverrate, mutationpolicy, mutationrate, selectionpolicy);

				Population lastpopulation = geneticalgorithm.evolve(startpopulation, stoppingcondition);
				double elapsedTime = (System.nanoTime() - time) / 1000000000.0;
				Log.get().possiblePlacement(((WASNChromosome)lastpopulation.getFittestChromosome()).hasPossiblePlacement());
				Log.get().addFitness(lastpopulation.getFittestChromosome().getFitness());
				Log.get().setGenerations(2000);
				Log.get().endEntry(elapsedTime);
				System.out.println(", f=" + lastpopulation.getFittestChromosome().getFitness() + ", t=" +elapsedTime);
				
			}
		}
		Log.get().stop();
	}
}
