package geneticalgorithm;

import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;

import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.Population;

/**
 * Population, thats list of chromosomes is public accessible
 * 
 * @author Konrad Horbach
 *
 */
public class SortedPopulation implements Population {

	PriorityQueue<Chromosome> population;
	int populationLimit;

	public SortedPopulation(int populationLimit) throws NotPositiveException {
		this.populationLimit = populationLimit;
		this.population = new PriorityQueue<Chromosome>(new MyComparator());
	}

	public PriorityQueue<Chromosome> getChromosomes() {
		return population;
	}

	/**
	 * generates a new generation containing the fittest chromosomes of the
	 * current generation
	 */
	public Population nextGeneration() {
		SortedPopulation nextGeneration = new SortedPopulation(this.getPopulationLimit());

		int size = this.getPopulationSize();

		for (int i = 0; i < size * 0.1; i++)
			nextGeneration.addChromosome(new WASNChromosome((WASNChromosome) this.population.poll()));

		return nextGeneration;
	}

	public String toString() {
		String s = "";

		for (Chromosome c : population)
			s += c + " ";

		return s;
	}

	public Iterator<Chromosome> iterator() {
		return population.iterator();
	}

	public void addChromosome(Chromosome e) throws NumberIsTooLargeException {
		if (population.size() == populationLimit)
			throw new NumberIsTooLargeException(LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE,
					population.size(), populationLimit, false);
		else
			population.add(e);

	}

	public Chromosome getFittestChromosome() {
		return population.peek();
	}

	public int getPopulationLimit() {
		return populationLimit;
	}

	public int getPopulationSize() {
		return population.size();
	}
	
	class MyComparator implements Comparator<Chromosome> {

		public int compare(Chromosome o1, Chromosome o2) {
			if (o1.getFitness() > o2.getFitness())
				return -1;
			if (o1.getFitness() < o2.getFitness())
				return 1;
			return 0;
		}

	}
}
