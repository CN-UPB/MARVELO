package geneticalgorithm;

import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.ChromosomePair;
import org.apache.commons.math3.genetics.CrossoverPolicy;

import utilities.*;

public class WASNCrossoverPolicy implements CrossoverPolicy {


	public ChromosomePair crossover(Chromosome c1, Chromosome c2) throws MathIllegalArgumentException {
		WASNChromosome chromosome1 = new WASNChromosome((WASNChromosome) c1);
		WASNChromosome chromosome2 = new WASNChromosome((WASNChromosome) c2);
		ChromosomePair pair = new ChromosomePair(chromosome1, chromosome2);

		for (int i = 0; i < chromosome1.getPlacement().length; i++) {

			int old1 = chromosome1.getPlacement()[i];
			int old2 = chromosome2.getPlacement()[i];

			if (StaticRandom.nextDouble() > 0.5) {
				chromosome1.placeBlock(old2, i);
				chromosome2.placeBlock(old1, i);
			}
		}
		// Crossover Priorities
		for (int i = 0; i < chromosome1.getPriorities().length; i++)
			for (int j = 0; j < chromosome1.getPriorities().length; j++)
				if (StaticRandom.nextDouble() < 0.5)
					chromosome1.getPriorities()[i][j] = (chromosome1.getPriorities()[i][j]
							+ chromosome2.getPriorities()[i][j]) / 2;
				else
					chromosome2.getPriorities()[i][j] = (chromosome1.getPriorities()[i][j]
							+ chromosome2.getPriorities()[i][j]) / 2;

		// Crossover Edgecosts
		for (int i = 0; i < chromosome1.getEdgecosts().length; i++)
			for (int j = 0; j < chromosome1.getEdgecosts().length; j++)
				if (StaticRandom.nextDouble() < 0.5)
					chromosome1.getEdgecosts()[i][j] = (chromosome1.getEdgecosts()[i][j]
							+ chromosome2.getEdgecosts()[i][j]) / 2;
				else
					chromosome2.getEdgecosts()[i][j] = (chromosome1.getEdgecosts()[i][j]
							+ chromosome2.getEdgecosts()[i][j]) / 2;
		
		return pair;
	}
}
