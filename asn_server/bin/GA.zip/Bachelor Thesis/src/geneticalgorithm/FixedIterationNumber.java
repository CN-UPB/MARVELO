package geneticalgorithm;

import org.apache.commons.math3.genetics.Population;
import org.apache.commons.math3.genetics.StoppingCondition;

/**
 * a stopping condition, that affects a Genetic Algorithm to terminate after a
 * fixed number of iterations
 * 
 * @author Konrad Horbach
 *
 */
public class FixedIterationNumber implements StoppingCondition {

	int counter;

	/**
	 * creates the stopping condition
	 * 
	 * @param number
	 *            the amount of generations of a Genetic Algorithm
	 */
	public FixedIterationNumber(int number) {
		counter = number;
	}

	public boolean isSatisfied(Population arg0) {
		return counter-- == 0;
	}

}
