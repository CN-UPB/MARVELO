package geneticalgorithm;

import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.ChromosomePair;
import org.apache.commons.math3.genetics.Population;
import org.apache.commons.math3.genetics.SelectionPolicy;

import utilities.*;
/**
 * returns chromosomes with better fitness with a higher probability
 * @author Konrad Horbach
 */


public class WASNSelectionPolicy implements SelectionPolicy{

	public ChromosomePair select(Population population) throws MathIllegalArgumentException {
		double fitnesssum = 0;
		Chromosome c1 = null, c2 = null;
		
		for(Chromosome c: population)
			fitnesssum += c.getFitness();
		
		double random = StaticRandom.nextDouble()*fitnesssum;
		double counter = 0;
		for(Chromosome c: population){
			counter += c.getFitness();
			if(counter >= random){
				c1 = c;
				break;
			}
		}
		
		random = StaticRandom.nextDouble()*fitnesssum;
		counter = 0;
		for(Chromosome c: population){
			counter += c.getFitness();
			if(counter >= random){
				c2 = c;
				break;
			}
		}
		
		return new ChromosomePair(c1,c2);
	}

}
