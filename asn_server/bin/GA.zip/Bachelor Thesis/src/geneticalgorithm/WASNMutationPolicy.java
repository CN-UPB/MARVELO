package geneticalgorithm;

import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.genetics.Chromosome;
import org.apache.commons.math3.genetics.MutationPolicy;

import utilities.*;

public class WASNMutationPolicy implements MutationPolicy {

	public Chromosome mutate(Chromosome c) throws MathIllegalArgumentException {
		WASNChromosome chromosome = new WASNChromosome((WASNChromosome) c);

		// mutate placement
		int block = (int) (StaticRandom.nextDouble() * chromosome.getPlacement().length);
		int node = (int) (StaticRandom.nextDouble() * chromosome.getNodecount());
		chromosome.placeBlock(node, block);

		// mutate edgecosts
		double[][] newEdges = Routing.eliminateEdges(chromosome.wasn);
		for (int i = 0; i < chromosome.wasn.getNodecount(); i++) {
			int j = (int) (StaticRandom.nextDouble() * chromosome.wasn.getNodecount());
			int k = (int) (StaticRandom.nextDouble() * chromosome.wasn.getNodecount());
			if (newEdges[j][k] != 0)
				chromosome.getEdgecosts()[j][k] = StaticRandom.nextDouble() + 1;
		}

		// mutate priorities
		for (int i = 0; i < chromosome.tasks.getBlockcount(); i++) {
			int j = (int) (StaticRandom.nextDouble() * chromosome.tasks.getBlockcount());
			int k = (int) (StaticRandom.nextDouble() * chromosome.tasks.getBlockcount());
			chromosome.getPriorities()[j][k] = (int) (StaticRandom.nextDouble() * chromosome.tasks.getBlockcount());
		}

		return chromosome;
	}

}
