package geneticalgorithm;

import java.util.Comparator;
import java.util.PriorityQueue;

import data.WASN;

/**
 * contains methods for routing
 * 
 * @author Konrad Horbach
 *
 */
public class Routing {

	/**
	 * creates a routing table using the dijkstra algorithm
	 * 
	 * @param edgecosts
	 *            edge costs of the graph
	 * @return a matrix that describes the routing table
	 */
	public static int[][] dijkstraRouting(double[][] edgecosts) {
		int[][] routingtable = new int[edgecosts.length][edgecosts.length];

		for (int startnode = 0; startnode < routingtable.length; startnode++) {

			double[] cost = new double[routingtable.length];

			for (int i = 0; i < cost.length; i++)
				cost[i] = Double.POSITIVE_INFINITY;

			int[] prev = new int[routingtable.length];
			for (int i = 0; i < prev.length; i++)
				prev[i] = -1;

			Comparator<Integer> comparator = new MyComparator(cost);
			PriorityQueue<Integer> queue = new PriorityQueue<Integer>(comparator);

			queue.add(startnode);
			cost[startnode] = 0;
			prev[startnode] = startnode;
			while (!queue.isEmpty()) {
				int q = queue.poll();

				for (int i = 0; i < routingtable.length; i++) {
					if (edgecosts[q][i] != Double.POSITIVE_INFINITY) {
						if (cost[i] >= cost[q] + edgecosts[q][i]) {
							cost[i] = cost[q] + edgecosts[q][i];
							if (prev[i] == -1) {
								queue.add(i);
							}
							prev[i] = q;
						}
					}
				}
			}
			for (int i = 0; i < routingtable.length; i++) {
				int j = i;
				while (j != -1 && prev[j] != startnode)
					j = prev[j];
				routingtable[startnode][i] = j;
			}
		}

		return routingtable;
	}

	/**
	 * determines if a transmission is possible on an edge considering no
	 * interference occurs
	 * 
	 * @param edges
	 *            attenuation matrix
	 * @param minAttenuation
	 *            threshold for attenuation to exceed the
	 * @return a matrix with item = 1 if a transmission is possible, or item = 0
	 *         if it is not possible
	 */
	public static double[][] getTransmissionNumber(double[][] edges, double minAttenuation) {
		double[][] newedges = new double[edges.length][edges.length];
		for (int i = 0; i < edges.length; i++)
			for (int j = 0; j < edges.length; j++)
				if (edges[i][j] >= minAttenuation)
					newedges[i][j] = 1.0;
				else
					newedges[i][j] = Double.POSITIVE_INFINITY;
		return newedges;
	}

	/**
	 * sets edges that don't exceed the SINR threshold to zero
	 * @param wasn
	 * @return
	 */
	public static double[][] eliminateEdges(WASN wasn) {
		double[][] oldEdges = wasn.getAttenuation();
		double[][] newEdges = new double[oldEdges.length][oldEdges.length];

		for (int i = 0; i < newEdges.length; i++)
			for (int j = 0; j < newEdges.length; j++)
				if (oldEdges[i][j] >= wasn.getSINRth() * wasn.getNoisefloor() / wasn.getSignalpower())
					newEdges[i][j] = oldEdges[i][j];

		return newEdges;

	}

}

/**
 * Comparator, that compares nodes by their cost to reach them
 * 
 * @author Konrad Horbach
 *
 */
class MyComparator implements Comparator<Integer> {

	double[] cost;

	MyComparator(double[] cost) {
		this.cost = cost;
	}

	public int compare(Integer o1, Integer o2) {
		if (cost[o1] > cost[o2])
			return 1;
		if (cost[o1] < cost[o2])
			return -1;
		return 0;
	}

}
